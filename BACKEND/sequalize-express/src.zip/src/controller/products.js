const models = require("../models");
const products = [];
const imageProduct = require("../models/imagesProducts");

const { Op } = require("sequelize");

const getAddProduct = (req, res) => {
  res.send(
    '<form action="/admin/add-product" method="POST"><label htmlFor="title">Title</label><input type="text" name="title" /><button type="submit">Add</button></form>'
  );
};

const postAddProduct = (req, res) => {
  const title = req.body.title;
  const imageUrl = req.body.imageUrl;
  const price = req.body.price;
  const description = req.body.description;
  const userId = req.body.userId;
  const stock = req.body.stock;
  const stars = req.body.stars;
  const reviews = req.body.reviews;
  const company = req.body.company;
  const featured = req.body.featured;
  const shipping = req.body.shipping;
  const category = req.body.category;
  const colors = req.body.colors;

  models.product
    .create({
      title,
      imageUrl,
      price,
      description,
      userId,
      stock,
      stars,
      reviews,
      company,
      featured,
      shipping,
      category,
      colors,
    })
    .then((result) => {
      console.log("ini", result.toJSON());
      console.log("create");
      res.send("success");
    })
    .catch((err) => {
      console.log(err);
    });
};

const getProduct = (req, res) => {
  res.json({
    data: products,
    total: products.length,
  });
};

const getAllProduct = (req, res) => {
  models.product
    .findAll({
      where: {
        id: 25,
      },
      include: [
        {
          model: imageProduct,
          as: "Images",
        },
      ],
    })
    .then((result) => {
      if (result.length > 0) {
        res.status(200).json({
          message: "All Product",
          data: result,
          totalData: result.length,
        });
      } else {
        res.status(200).json({
          message: "Empty",
          data: [],
        });
      }
    })
    .catch((err) => {
      res.status(400).json({
        message: err.message,
      });
    });
};

const getOneProduct = (req, res) => {
  const id = req.params.id;

  models.product
    .findByPk(id)
    .then((result) => {
      if (result) {
        res.status(200).json({
          message: "Data Found",
          data: result,
        });
      } else {
        res.json({
          message: "Data Not Found",
        });
      }
    })
    .catch((err) => {
      res.json({
        message: err.message,
      });
    });
};

module.exports = {
  getAddProduct,
  postAddProduct,
  getProduct,
  getAllProduct,
  getOneProduct,
};
