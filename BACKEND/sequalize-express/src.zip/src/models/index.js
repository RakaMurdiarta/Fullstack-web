const product = require("./product");
const cart = require("./cart");
const cartItem = require("./cartItems");
const users = require("./users");
const imagesProducts = require("./imagesProducts");

const Model = {};

Model.product = product;
Model.cart = cart;
Model.cartItem = cartItem;
Model.users = users;
Model.imagesProducts = imagesProducts;

console.log(users);

users.hasOne(cart);

users.hasMany(product, {
  constraints: true,
  onDelete: "CASCADE",
  foreignKey: "userId",
});

cart.hasMany(cartItem, {
  constraints: true,
  onDelete: "CASCADE",
  foreignKey: "cartId",
});

product.hasMany(cartItem, {
  constraints: true,
  onDelete: "CASCADE",
  foreignKey: "productId",
});

product.hasMany(imagesProducts, {
  constraints: true,
  onDelete: "CASCADE",
  foreignKey: "productId",
  as: "Images",
});

module.exports = Model;
