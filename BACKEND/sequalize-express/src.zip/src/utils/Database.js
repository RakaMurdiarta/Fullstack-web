const Sequelize = require("sequelize");
const sequelize = new Sequelize("ecommerce2", "admin", "1234", {
  dialect: "mysql",
  host: "localhost",
});



module.exports = sequelize;
