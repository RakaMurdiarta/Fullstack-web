const logRes=(req,res,next)=>{
    res.send("Processing Requset")
}

module.exports={logRes}
