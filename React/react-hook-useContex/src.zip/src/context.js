import React, { useState, useContext } from 'react';

const AppContext = React.createContext();
console.log(AppContext);
const AppProvider = ({ children }) => {


  //start
  const [isSidebarOpen,setIsSidebarOpen]=useState(false)
  const [isModalOpen,setIsModalOpen]=useState(false)


  function SidebarOpen() {
    setIsSidebarOpen(true)
  }
  function CloseSidebar() {
    setIsSidebarOpen(false)
  }

  function openModal() {
    setIsModalOpen(true)
  }
  function modalClose() {
    setIsModalOpen(false)
  }
  return (
    <AppContext.Provider
      value={{isSidebarOpen,SidebarOpen ,CloseSidebar,isModalOpen,openModal,modalClose}}
    >
      {children}
    </AppContext.Provider>
  );
};


export { AppContext, AppProvider };
