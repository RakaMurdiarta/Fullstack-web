// import { Component } from 'react';
import './button.css'


function Button() {
    return(
        <input className='input-btn' type="button" value="Login" />
    )
}

export default Button;