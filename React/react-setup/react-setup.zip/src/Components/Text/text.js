import './text.css';
function Text() {
    return (
        <div className='wrapper1'>
            <p className="text">Selamat Datang di React Pertama Saya</p>
            <p className="text text1">Copyright 2022</p>
        </div>
    );
}

export default Text;