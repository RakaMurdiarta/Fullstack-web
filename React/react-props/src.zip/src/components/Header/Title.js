import React from 'react'
function Title(props) {
    return ( 
        <h1>{props.appTitle}</h1>
     );
}

export default Title;