import React from 'react'

function UserPofile() {
    return (
        <div>
            <img src="https://static.thenounproject.com/png/363633-200.png" alt="" />
            <h3>Superman</h3>
        </div>
    );
}

export default UserPofile;