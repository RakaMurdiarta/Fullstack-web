import React from 'react'
const CartColumns = () => {
  return (
    <div>
      
    </div>
  )
}


export default CartColumns
