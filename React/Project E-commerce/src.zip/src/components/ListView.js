import React from 'react'
import { formatPrice } from '../utils/helpers'
import { Link } from 'react-router-dom'
import './listview.css'

const ListView = ({ products }) => {
  return (
    <section>
      {
      //map products and each return product info wrapped in article tag

      }
    </section>
  )
}

export default ListView
