import React from 'react'
import Product from './Product'
import './gridview.css'

const GridView = ({ products }) => {
  return (
    <div>
      
    </div>
  )
}

export default GridView
