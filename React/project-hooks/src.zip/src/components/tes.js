import Items from '../data'

console.log(Items);