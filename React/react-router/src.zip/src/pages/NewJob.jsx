import React from 'react'

const NewJob = () => {
  return (
    <div>NewJob</div>
  )
}

export default NewJob